S14 File. Per-pair results of the uncertainty-aware comparisons (Osgood-Zimmerman & Raredon).

regional.csv: one row per ligand-receptor pair and fixed region comparison (1,477 x 13). plug_ratio: ratio of regional
  averages on the published plug-in map (first region / second); wilcox_p: two-sided Wilcoxon rank-sum p, bins as
  independent; post_med, lo, hi: posterior median and 95% interval of the ratio; credible: interval excludes 1;
  dec_lo, dec_hi, dec_credible: the same with each bin's draws permuted independently; flagged: pair involves a gene
  whose refit differs from the published fit (S13 Table).
crossfield.csv: one row per pair of fields sharing a ligand or receptor (a, b) and region; each field divided by its
  own field-of-view average within each draw; wilcox_signed_p: paired Wilcoxon signed-rank on the plug-in fields.
slices.csv: one row per pair and transect: n positions; n_pointwise: positions with posterior probability >= 0.95 of
  being above or below the transect average; n_simband: positions where the simultaneous 95% band excludes 0;
  n_joint: positions in the joint 95% excursion sets; ld_T, ld_T_joint: positions that look different at threshold T
  (|plug-in log deviation| >= log T), and how many of those are in the joint sets; alike_joint_125: positions that
  look alike at T = 1.25 but are in the joint sets.
check2.csv: per-gene reproduction check (med_dlog, width_ratio, flag).
flagged-refit-plugin.csv: flagged pairs with the plug-in ratio from the published fit and from the refit.
